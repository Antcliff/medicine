<?php get_header(); ?>
    <!-- Main jumbotron for a primary marketing message or call to action -->
<!-- Begin page content -->
    <div id="primary" class="container-fluid ">
     <main id="main" class="site-main" role="main">        
 <section id="image">
   <div class="image-content">
  <h1 class="heading1">Transforming</h1>
  <h1 class="heading2">Health</h1>
    <p><b>Ranked #1</b> in the nation for something related to the school of medicine</p>
    <button id="button1">Join Our Team</button>
    <button id="button2">Learn More</button>
  </div>
 </section>
          
     <section id="about">
       <div class="indent">
    <?php
    $args = array(
     'posts_per_page' => 3,
     'orderby' => 'ID',
     'order' => 'ASC',
     'category_name' => 'about'
    
    );
     $query = new WP_query( $args );
       if ($query->have_posts()) { 
        echo '<ul class="about">';
         while ( $query->have_posts() ) {    
          $query->the_post();
           echo '<li>';
           echo '<figure class="about-thumb">';
          the_post_thumbnail('about-pic');
          echo '</figure>';
          echo '<aside class="about-alltext">';
          echo '<h3 class="about-name">' . get_the_title() . '</h3>';
          echo '<div class="about-text">';
          the_content('');
          echo '</div>';
          echo '</aside>';
          echo '</li>';
         }
        echo '</ul>';
       }
        
        wp_reset_postdata();
        
     ?>
        
        
      </div>
     </section>
     <section id="education">
      <div class="education_back">
        
        <div class="indent">
     <?php
     $query = new WP_query( 'pagename=education');
       
      //Loops through each page content and displays on front page       
       if ($query->have_posts()) {        
        while ( $query->have_posts() ) {         
          $query->the_post();
         echo '<div class="education-content">';
         the_content();
         echo '</div>';
        }
        
       } // end if
        
        wp_reset_postdata();
        
     ?>
         
       </div> 
      </div><!-- education back -->
 <div class="indent">
      <div class="medical_program">
         <div id="medical_education">
             <h3><?php $pageID = 50;
                   $page = get_post($pageID);
              echo $page->post_title; ?></h3>
             <div id="medical_education_content">
              <?php  $id=50; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
              ?>
              </div>
         </div>
                   <div id="education_program">
                      <h3><?php $pageID = 58;
                   $page = get_post($pageID);
              echo $page->post_title; ?></h3>
                      <div id="education_program_content">
              <?php  $id=58; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
              ?>
              </div>
                   <div id="expand">
        <ul>
            <li>
                <a href="#" onclick="swap('sectionOneLinks');return false;">+ MD</a>
                <ul id="sectionOneLinks" style="display: none;">
                   <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="swap('sectionTwoLinks');return false;">+ Ph.D</a>
                <ul id="sectionTwoLinks" style="display: none;">
                   <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="swap('sectionThreeLinks');return false;">+ Combined Degrees</a>
                <ul id="sectionThreeLinks" style="display: none;">
                    <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                </ul>
            </li>
          <li>
                <a href="#" onclick="swap('sectionFourLinks');return false;">+ Undergraduate Degrees</a>
                <ul id="sectionFourLinks" style="display: none;">
                    <li>A link to a page</li>
                   <li>A link to a page</li>
                  <li>A link to a page</li>
                  <li>A link to a page</li>
                </ul>
            </li>
          <li>
                <a href="#" onclick="swap('sectionFiveLinks');return false;">+ Residency</a>
                <ul id="sectionFiveLinks" style="display: none;">
                   <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                  <li>Random text</li>
                </ul>
            </li>
        </ul>
    </div>
                                                                                            
       
      </div>
  </div>
     
   <div class="sub-nav">
   <!-- Static navbar -->
      <nav class="navbar navbar-default">
       <h3 id="title_sec_menu">Popular Student Resources</h3>
       <div class="dropdown">

    <!-- trigger button -->
    <button id="sub">Menu</button>
       <?php wp_nav_menu(array( 'sort_column' => 'menu_order', 'menu' => 'Categories', 'container_class' => 'main-menu', 'container_id' => 'header', 'theme_location'  => 'secondary_menu') ); ?>
       </div>
       
      </nav>
   </div>
       
     </section>
     <section id="research">
      <div id="research_back">
       <div class="indent">
      <h3><?php $pageID = 79;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3>
        <div class="research_education_content">
        <?php  $id=79; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
              ?>
        
        
        </div>
      </div>
      </div>
      <div class="research_banner_back">
       <div class="indent">
           <h3><?php $pageID = 88;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3>
          <div class="research_medical_content">
        <?php  $id=88; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
              ?>
        
        
        </div>
        
        
        
       </div>
       
      
      
      </div>
      </section>
     <section id="clinical">      
      <div class="indent">
       <div class="tabbable tabs-left">
        <ul class="pad nav-tabs">
          <li class="active"><a href="#a" data-toggle="tab"> <h3><?php $pageID = 92;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3></a></li>
          <li ><a href="#b" data-toggle="tab"><h3><?php $pageID = 94;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3></a></li>
          <li><a href="#c" data-toggle="tab"><h3><?php $pageID = 101;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3></a></li>
          <li><a href="#d" data-toggle="tab"> <h3><?php $pageID = 164;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3></a></li>
          <li><a href="#e" data-toggle="tab"> <h3><?php $pageID = 166;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3></a></li>
          <li><a href="#f" data-toggle="tab"> <h3><?php $pageID = 170;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3></a></li>
        </ul>
        <div class="tab-content">
         <div class="tab-pane active" id="a"> <?php  $id=92; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
          echo '<div class="brain_content">';
            echo '<figure class="area-thumb">';
          the_post_thumbnail('areas-pic');
          echo '</figure>';
           echo $content;  
          echo '</div>';
        
            
                
              ?></div>
         <div class="tab-pane" id="b"> <?php  $id=94; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
                echo '<div class="brain_content">';
          echo '<figure class="area-thumb">';
          the_post_thumbnail('areas-pic');
          echo '</figure>';
          echo $content;  
          echo '</div>';
              ?></div>
         <div class="tab-pane" id="c"> <?php  $id=101; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo '<div class="brain_content">';
          echo '<figure class="area-thumb">';
          the_post_thumbnail('areas-pic');
          echo '</figure>';
          echo $content;  
          echo '</div>';
              ?> </div>
           <div class="tab-pane" id="d"> <?php  $id=164; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo '<div class="brain_content">';
          echo '<figure class="area-thumb">';
          the_post_thumbnail('areas-pic');
          echo '</figure>';
          echo $content;  
          echo '</div>';
              ?> </div>
         
           <div class="tab-pane" id="e"> <?php  $id=166; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo '<div class="brain_content">';
          echo '<figure class="area-thumb">';
          the_post_thumbnail('areas-pic');
          echo '</figure>';
          echo $content;  
          echo '</div>';
              ?> </div>
         
           <div class="tab-pane" id="f"> <?php  $id=170; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo '<div class="brain_content">';
          echo '<figure class="area-thumb">';
          the_post_thumbnail('areas-pic');
          echo '</figure>';
          echo $content;  
          echo '</div>';
              ?> </div>
        </div>
      </div>
      </div>
       <div class="meet">
        <div class="indent">
       <h3><?php $pageID = 106;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3>
       <div class="meet-doc">
       
      <?php  
        echo '<div class="meet-title">'; 
        
               $id=180; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               
          echo '<figure class="meet-thumb">';
          the_post_thumbnail('meet-pic');
          echo '</figure>';
       
           $pageID = 180;
     $page = get_post($pageID);
        echo $page->post_title; 
       
          echo $content;  
          echo '</div>';
         
          
          echo '<div class="meet-content">';
             echo '<div style="border:3px solid #7d110c;"></div>';
          echo'<h3>';
        $pageID = 182;
         $page = get_post($pageID);
         echo $page->post_title; 
        echo '</h3>';
         $id=182; 
         $post = get_post($id); 
         $content = apply_filters('the_content', $post->post_content);        
          echo $content; 
        
        
         echo '</div>';
        
        echo '<div class="meet-title-2">';
              $id=186; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               
          echo '<figure class="meet-thumb">';
          the_post_thumbnail('meet-pic');
          echo '</figure>';
          
       
           $pageID = 186;
     $page = get_post($pageID);
        echo $page->post_title; 
       
          echo $content;  
        
        echo '</div>';
  
        echo '<div class="meet-content-2">';
             echo '<div style="border:3px solid #7d110c;"></div>';
          echo'<h3>';
        $pageID = 188;
         $page = get_post($pageID);
         echo $page->post_title; 
        echo '</h3>';
         $id=188; 
         $post = get_post($id); 
         $content = apply_filters('the_content', $post->post_content);        
          echo $content; 
        
        
         echo '</div>';
        
        
              ?> 
  
       </div>
       
       
       </div>
        
      </div>
    
       
       
       
       
     
    
     </section>
     <section id="academic">
      <div id="academic_back">    
      <div class="indent">
       <h3><?php $pageID = 111;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3>
          <div class="academic_content">
        <?php  $id=111; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
              ?>
       </div>
       </div>      
       
      </div>
    <div id="locations">
   <div class="indent">
      <img class="img-responsive" src="<?php bloginfo('template_directory'); ?>/images/state.png" alt=""/> 
     </div>
      </div>
      
      <div class="partnership">
         <div class="indent">
             <h3><?php $pageID = 115;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3>
          <div class="partnership_content">
        <?php  $id=115; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
              ?>      
         </div>
          <div class="partnership_image">
          
           <img class="img-responsive" src="<?php bloginfo('template_directory'); ?>/images/partner_image.png" alt=""/> 
          
          </div>
      
      
      
      </div>
     
      
          
       
     </section>
      
        <section id="careers" >      
     
           <div class="careers_back">
            <div class="indent">
              <div class="box">
             <h3 id="test"><?php $pageID = 120;
               $page = get_post($pageID);
               echo $page->post_title; ?></h3>
             <div class="careers_content">
              <p id="ptest"><?php  $id=120; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
               ?></p>
              

            </div>
            
           </div> 
        
        </div>
       
      </div>
      </section>
        <section id="news">
          <div class="inside">
           <div class="indent">            
              <h3><?php $pageID = 124;
     $page = get_post($pageID);
     echo $page->post_title; ?></h3>
            <div class="inside_content">
            <?php  $id=124; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
               ?>
               <form class="navbar-form" role="search">
                 <div class="input-group add-on">
                   <input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term">
                   <div class="input-group-btn">
                     <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                   </div>
                 </div>
               </form>

            </div>
            
            
         <?php dynamic_sidebar('sidebar-1'); ?>
          
          
            </div>
         
         
         
         </div>
      </section>
         
         
   
      <section id="footer">
       <div class="indent">
         <div class="left-footer">
          <h3><?php $pageID = 142;
          $page = get_post($pageID);
          echo $page->post_title; ?>
          </h3>
              <div class="footer_content">
         <?php  $id=142; 
               $post = get_post($id); 
               $content = apply_filters('the_content', $post->post_content); 
               echo $content;  
               ?>
        
            </div>
       
         </div>
        
        <div class="left-middle-footer">
         <h3>Subscribe</h3>
         <div class="left-middle-content">
              <form class="navbar-form" role="search">
                 <div class="input-group add-on">
                   <input type="email" class="form-control" placeholder="Enter Email Address" name="email" id="email">
                   <div class="input-group-btn">
                     <button class="btn1" type="submit"><i class="glyphicon glyphicon-arrow-right"></i></button>
                   </div>
                 </div>
               </form>
          <p>Sign up for the IUSM e-newsletter. We respect your privacy adn will not share your email address</p>
         
         </div>
        
        
        </div>
        
        <div class="right-middle-footer">
         <h3>Popular Resources</h3>
         <div class="footer-links">
          <div class="left-links">
           <li><a href="#">Apply</a></li>
           <li><a href="#">Degreen Programs</a></li>
           <li><a href="#">Library</a></li>
           <li><a href="#">Campuses</a></li>
          </div>
          <div class="right-links">
           <li><a href="#">Students</a></li>
           <li><a href="#">Faculty</a></li>
           <li><a href="#">Alumi</a></li>
           <li><a href="#">Donors</a></li>         
          </div>
         
         
         </div><!-- footer links -->
        
        </div><!-- right middle -->
        <div class="right-footer">
         <h3>Connect with us!</h3>
        <div class="social">
          <div class="twitter">
           <a href="#"><img class="img-responsive" src="<?php bloginfo('template_directory'); ?>/images/twitter.png" alt=""/> </a>
          </div>
         <div class="facebook">
          <a href="#"> <img class="img-responsive" src="<?php bloginfo('template_directory'); ?>/images/facebook.png" alt=""/> </a>
         
         </div>
         <div class="linkedin">
          <a href="#"><img class="img-responsive" src="<?php bloginfo('template_directory'); ?>/images/linkedin.png" alt=""/> </a>
        
         
         </div>
         
         
        </div>
        
        </div>
        
        
        
       </div><!-- indent -->
      
      
      
      </section>
      
   
      
      
	</main><!-- .site-main -->



</div><!-- .content-area -->
<?php get_footer(); ?>
     