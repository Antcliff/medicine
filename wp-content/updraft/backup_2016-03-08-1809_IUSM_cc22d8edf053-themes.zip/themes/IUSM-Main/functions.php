<?php
// Register Custom Navigation Walker
require_once('wp_bootstrap_navwalker.php');

register_nav_menus( array(
    'primary' => __( 'Primary Menu', 'School of Medicine IU' ),
    'secondary_menu' => __( 'Secondary Menu', 'School of Medicine IU'),
 'areas_menu' => __( 'Areas Menu', 'School of Medicine IU')
   
) );


add_theme_support( 'post-thumbnails' ); 

add_image_size( 'about-pic',  100, 50, true);

add_image_size('areas-pic', 200, 300, true);


add_image_size('meet-pic', 100, 100, true);






?>