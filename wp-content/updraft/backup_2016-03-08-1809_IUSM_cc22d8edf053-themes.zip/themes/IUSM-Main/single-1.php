<?php /* Template Name: Slide1 */ 
get_header();

?>


<?php get_footer(); ?>