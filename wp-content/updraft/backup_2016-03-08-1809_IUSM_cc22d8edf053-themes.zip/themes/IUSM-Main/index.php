<?php get_header(); ?>
    <!-- Main jumbotron for a primary marketing message or call to action -->
<!-- Begin page content -->
    <div class="container">
      <div class="page-header">
        <h1>IUSM</h1>
      </div>
      <p class="lead">This page is no use please select an active page</p>
      
    </div>
<?php get_footer(); ?>
     